# -*- coding: utf-8 -*-
"""Klinik teyit (akis_sorulari.md, 2026-10-07) kararlarının modele uygulanması.

model_data.py kaynaklardan (PDF + Excalidraw) çıkan ham kodlamayı tutar; bu dosya
klinik ekibin cevaplarını üstüne yazar. Her değişiklik `clinicalReview` kaydıyla
hangi soruya dayandığını taşır, böylece Excalidraw yeniden derlendiğinde kararlar kaybolmaz.
"""
from model_data import *  # noqa: F401,F403  (STEPS, INSTRUMENTS, CONDITIONS, BRANCHES, NEXT_OVERRIDE, I, PREOP içermez)

VERSION = "2.0.0"
FILE_NAME = "open-appendectomy-v2.json"
REVIEW_SOURCE = {"file": "akis_sorulari.md", "receivedAt": "2026-10-07", "reviewer": "Klinik ekip (ameliyathane eğitmeni)"}


def review(n, q, decision, note=None):
    STEPS[n].setdefault("review", []).append({"question": q, "decision": decision, **({"note": note} if note else {})})


def resolve_conflicts(n, q, text):
    for c in STEPS[n].get("conflicts", []):
        c["status"] = "RESOLVED_BY_CLINICAL_REVIEW"
        c["reviewQuestion"] = q
        c["resolution"] = text


def drop(n, code):
    STEPS[n]["inst"] = [i for i in STEPS[n]["inst"] if i["code"] != code]


# ---------------------------------------------------------------- katalog
INSTRUMENTS.update({
    "FORCEPS_DEBAKEY": {"name": "DeBakey diseksiyon penseti", "category": "forceps"},
    "CLAMP_MOSQUITO": {"name": "Mosquito klemp", "category": "clamp", "vesselCaliber": "SMALL"},
    "CLAMP_PEAN": {"name": "Pean klemp", "category": "clamp", "vesselCaliber": "LARGE"},
    "RETRACTOR_LANGENBECK": {"name": "Langenbeck ekartör", "category": "retractor"},
    "RETRACTOR_RICHARDSON": {"name": "Richardson ekartör", "category": "retractor"},
})
# S30: hemostatik klempler aynı şekil, farklı uç kalınlığı → damar çapı
INSTRUMENTS["CLAMP_CRILE_CURVED_14"]["vesselCaliber"] = "MEDIUM"
INSTRUMENTS["CLAMP_CRILE_STRAIGHT_14"]["vesselCaliber"] = "MEDIUM"
HEMOSTAT_BY_CALIBER = {"SMALL": "CLAMP_MOSQUITO", "MEDIUM": "CLAMP_CRILE_CURVED_14", "LARGE": "CLAMP_PEAN"}

# S29: Metzenbaum sete eklenecek; sütür ve serum haricen açılan sarf
for code in ("SCISSORS_METZENBAUM", "SCISSORS_METZENBAUM_CURVED"):
    INSTRUMENTS[code].pop("inApendectomySetImage", None)
    INSTRUMENTS[code].update({"inSet": True, "supply": "SET", "note": "Klinik teyit S29: apendektomi setine eklenecek"})
for code, d in INSTRUMENTS.items():
    if d["category"] in ("suture",) or code in ("ISOTONIC_SALINE",):
        d.update({"inSet": False, "supply": "CONSUMABLE"})

# Emilebilirlik (malzeme bilgisi). Prolen = polipropilen → emilmez. Bkz. açık soru Q-A1.
ABSORBABLE = {
    "SUTURE_SILK_3_0": ("İpek", False),
    "SUTURE_POLYGLACTIN_2_0": ("Poliglaktin 910", True),
    "SUTURE_POLYGLACTIN_0": ("Poliglaktin 910", True),
    "SUTURE_POLYGLACTIN_1": ("Poliglaktin 910", True),
    "SUTURE_POLYPROPYLENE_0": ("Polipropilen", False),
    "SUTURE_POLYPROPYLENE_1": ("Polipropilen", False),
    "SUTURE_POLYAMIDE_4_0": ("Poliamid", False),
}
for code, (mat, ab) in ABSORBABLE.items():
    INSTRUMENTS[code].update({"material": mat, "absorbable": ab})
INSTRUMENTS["SUTURE_POLYPROPYLENE_0"]["absorbableNote"] = INSTRUMENTS["SUTURE_POLYPROPYLENE_1"]["absorbableNote"] = \
    "Klinik cevapta 'Prolen emilebilir' denmiş; polipropilen emilmeyen bir materyaldir. Teyit bekliyor (Q-A1)."

ACTIONS.update({"SEARCH": "Arama", "IMAGING": "Radyolojik görüntüleme", "RETRIEVE": "Malzemeyi çıkarma", "RECORD": "Kayıt"})
TARGETS.update({"PATIENT": "Hasta (görüntüleme)", "MISSING_ITEM": "Eksik malzeme"})

# ---------------------------------------------------------------- koşullar ve parametreler
# source: SCENARIO = seans başında senaryo belirler · ADAPTIVE = Adaptive Training Engine
# dijital ikize göre seans içinde seçer (AI önerebilir) · RUNTIME = kursiyerin olaylarından hesaplanır
CONDITIONS.update({
    "BLEEDING_AFTER_IRRIGATION": "Yıkama ve aspirasyondan sonra sahada kanama görüldü",
    "ITEM_FOUND_ON_RECOUNT": "Eksik malzeme tekrar sayımda bulundu (sayım hatası)",
    "ITEM_FOUND_IN_FIELD": "Eksik malzeme saha aramasında bulundu",
    "ITEM_FOUND_ON_IMAGING": "Eksik malzeme radyolojik görüntülemede hastada görüldü",
    "SURGICAL_SITE_INFECTION": "Kirli bistüri ucu kullanımına bağlı cerrahi alan enfeksiyonu gelişti",
})
CONDITION_META = {
    "EXPOSURE_INSUFFICIENT": {"source": "SCENARIO", "evaluatedAt": 11},
    "ADHESIONS_PRESENT": {"source": "SCENARIO", "evaluatedAt": 19, "scenarioField": "patient.hasAdhesion"},
    "LIGATURE_NOT_SECURE": {"source": "ADAPTIVE", "evaluatedAt": 29},
    "BLEEDING_DETECTED": {"source": "ADAPTIVE", "evaluatedAt": 40, "reviewQuestion": 27},
    "BLEEDING_AFTER_IRRIGATION": {"source": "ADAPTIVE", "evaluatedAt": 43, "reviewQuestion": 27},
    "COUNT_MISMATCH": {"source": "RUNTIME", "evaluatedAt": 47, "note": "count_confirmed sayıları beklenenle uyuşmadığında; senaryo eksik malzeme de enjekte edebilir"},
    "ITEM_FOUND_ON_RECOUNT": {"source": "ADAPTIVE", "evaluatedAt": "47a", "reviewQuestion": 26},
    "ITEM_FOUND_IN_FIELD": {"source": "ADAPTIVE", "evaluatedAt": "47b", "reviewQuestion": 26},
    "ITEM_FOUND_ON_IMAGING": {"source": "ADAPTIVE", "evaluatedAt": "47d", "reviewQuestion": 26},
    "SURGICAL_SITE_INFECTION": {"source": "ADAPTIVE", "evaluatedAt": "debrief", "kind": "OUTCOME", "reviewQuestion": 2,
                                "note": "Akışı değiştirmez; sonucu (debrief, skor, dijital ikiz) etkiler"},
}
PARAMETERS = {
    "PATIENT_BODY_TYPE": {"type": "enum", "values": ["THIN", "NORMAL", "OBESE"], "source": "SCENARIO",
                          "scenarioField": "patient.bodyType", "default": "NORMAL", "reviewQuestion": 11},
    "MESO_VESSELS": {"type": "list", "items": {"caliber": ["SMALL", "MEDIUM", "LARGE"]}, "source": "SCENARIO",
                     "default": [{"caliber": "MEDIUM"}, {"caliber": "MEDIUM"}], "reviewQuestion": 15,
                     "note": "Klemplenecek mezappendiks damarları; adet ve çap klemp sayısını ve tipini belirler"},
}

# ---------------------------------------------------------------- adım kararları
# Q1 · Adım 38
review(38, 1, "A+", "Babcock appendiksle birlikte formaldehitli kaba bırakılır; sirküle Babcock'u alıp kirli alanda tutar. Alet odadan çıkmaz, sayımda eksik oluşmaz.")
resolve_conflicts(38, 1, "Klinik teyit (S1): PDF doğru. Babcock kaba bırakılır, sirküle alıp kirli alanda tutar; alet sayımda kalır.")
STEPS[38]["by"] = ["SURGEON", "SCRUB", "CIRCULATOR"]
STEPS[38]["inst"] = [I("CLAMP_BABCOCK_16", "IN_USE", note="Spesimenle birlikte kaba bırakılır; sirküle alıp kirli alanda tutar"),
                     I("SPECIMEN_CONTAINER_FORMALIN_10", "SUPPORT", note="Sirküle hazırlar")]
STEPS[38]["notes"] = ["Babcock ameliyat odasından çıkmaz; kapanış sayımında kirli alanda sayılır."]
STEPS[38]["instrumentDisposition"] = {"code": "CLAMP_BABCOCK_16", "location": "DIRTY_AREA", "handledBy": "CIRCULATOR", "countedAtClosure": True}

# Q2 · Adım 9
review(9, 2, "B", "Uç değiştirilir. Değiştirilmezse enfeksiyon olasılığı; enfeksiyonun gelişip gelişmeyeceği dijital ikize göre adaptif motor/AI tarafından seçilir.")
resolve_conflicts(9, 2, "Klinik teyit (S2): Excalidraw doğru, bistüri ucu değiştirilir.")
STEPS[9]["adaptiveOutcomes"] = [{"onScenario": "S09-E3", "condition": "SURGICAL_SITE_INFECTION", "decidedBy": "ADAPTIVE_ENGINE",
                                 "inputs": ["digitalTwin.level", "digitalTwin.weakAreas.sterility"],
                                 "effect": "Postoperatif enfeksiyon olarak debrief'te gösterilir; sterilite skorunu etkiler"}]
STEPS[34].setdefault("adaptiveOutcomes", []).append(
    {"onScenario": "S34-E1", "condition": "SURGICAL_SITE_INFECTION", "decidedBy": "ADAPTIVE_ENGINE",
     "inputs": ["digitalTwin.level", "digitalTwin.weakAreas.sterility"], "effect": "Mevcut backend K4 (DIRTY_BLADE_INFECTION) ile aynı sonuç ailesi"})

# Q3 · Adım 1
review(1, 3, "A ve B", "Hekimin tercihine göre 10 veya 15 numara; ikisi de doğru.")
resolve_conflicts(1, 3, "Klinik teyit (S3): 10 ve 15 numara uç ikisi de kabul; hekim tercihi.")
STEPS[1]["inst"] = [I("SCALPEL_BLADE_10", "ALTERNATIVE", note="Hekim tercihi"), I("SCALPEL_BLADE_15", "ALTERNATIVE", note="Hekim tercihi"),
                    I("SCALPEL_HANDLE_3", "SUPPORT")]
STEPS[1]["variants"].append({"id": "SKIN_BLADE", "options": ["No:10", "No:15"], "decidedBy": "SURGEON"})

# Q4 · Adım 30
review(30, 4, "B", "Crile klemp; işaret için Babcock kullanılmaz.")
resolve_conflicts(30, 4, "Klinik teyit (S4): Crile klemp düz 14 cm; Babcock işaret pensi olarak kullanılmaz.")

# Q5 · Adım 50
review(50, 5, "Genişletildi", "1, 0 veya 2(/0) kullanılabilir; 2/0'dan ince iplik kullanılmaz. İplik emilebilir olmalı (kritik).")
resolve_conflicts(50, 5, "Klinik teyit (S5): 1, 0 veya 2/0; emilebilir iplik zorunlu. Prolen'in durumu Q-A1 ile teyit bekliyor.")
STEPS[50]["name"] = "Kas tabakasının emilebilir sütürle kapatılması"
STEPS[50]["inst"] = [I("NEEDLE_HOLDER_DEBAKEY_18"),
                     I("SUTURE_POLYGLACTIN_1", "ALTERNATIVE"), I("SUTURE_POLYGLACTIN_0", "ALTERNATIVE"),
                     I("SUTURE_POLYGLACTIN_2_0", "ALTERNATIVE", note="En ince kabul edilen kalınlık"),
                     I("SUTURE_POLYPROPYLENE_1", "ALTERNATIVE", note="TEYİT BEKLİYOR: polipropilen emilmez (Q-A1)"),
                     I("SUTURE_POLYPROPYLENE_0", "ALTERNATIVE", note="TEYİT BEKLİYOR: polipropilen emilmez (Q-A1)"),
                     I("FORCEPS_SEMKEN_NON_TOOTHED_15_5", "SUPPORT")]
STEPS[50]["variants"] = [{"id": "SUTURE_SIZE", "options": ["1", "0", "2/0"], "decidedBy": "SURGEON"}]
STEPS[50]["rules"] = [{"id": "R50-1", "text": "Kas tabakasında emilebilir sütür kullanılır.", "check": "instrument.absorbable == true"},
                      {"id": "R50-2", "text": "2/0'dan daha ince sütür (3/0, 4/0 ...) kullanılmaz.", "check": "suture.size >= 2/0"}]
STEPS[50]["pendingClinicalConfirmation"] = ["Q-A1", "Q-A2"]

# Q6–Q8, Q10, Q12, Q14, Q16–Q19 · Excalidraw (B) onaylandı
for q, n in [(6, 4), (7, 6), (8, 7), (10, 10), (12, 20), (14, 22), (16, 25), (17, 28), (18, 35), (18, 37), (19, 36)]:
    review(n, q, "B")
    resolve_conflicts(n, q, f"Klinik teyit (S{q}): Excalidraw (B) doğru.")
STEPS[10]["inst"] = [i for i in STEPS[10]["inst"] if not (i["code"] == "FORCEPS_STILLE_NON_TOOTHED_15" and i["usage"] == "IN_USE")]

# Q9 · Adım 8 → PDF (A)
review(8, 9, "A", "Periton Stille veya DeBakey diseksiyon penseti ile tutulur.")
resolve_conflicts(8, 9, "Klinik teyit (S9): PDF doğru, Stille veya DeBakey diseksiyon penseti.")
STEPS[8]["inst"] = [I("FORCEPS_STILLE_NON_TOOTHED_15", "ALTERNATIVE"), I("FORCEPS_DEBAKEY", "ALTERNATIVE")]
STEPS[8]["name"] = "Peritonun penset ile tutulması"

# Q11 · Adım 13 + vücut tipi kuralı
review(13, 11, "B + vücut tipi kuralı", "Kilolu hastada daha uzun uçlu ekartör gerekir; bu davranış öğretilmeli.")
resolve_conflicts(13, 11, "Klinik teyit (S11): Excalidraw (B) + PDF'teki hasta kilosuna göre ekartör kuralı eklendi.")
STEPS[13]["parameterRules"] = [{
    "parameter": "PATIENT_BODY_TYPE",
    "expectedInstruments": {
        "THIN": ["RETRACTOR_FARABEUF_15_SET", "RETRACTOR_LANGENBECK"],
        "NORMAL": ["RETRACTOR_LANGENBECK"],
        "OBESE": ["RETRACTOR_RICHARDSON"],
    },
    "source": "PDF alet tablosu, Adım 13 + klinik teyit S11",
    "status": {"OBESE": "PENDING_CONFIRMATION (Q-A4)", "NORMAL": "PENDING_CONFIRMATION (Q-A4)"},
    "note": "Kilolu hastada daha uzun uçlu ekartör; tam alet adı teyit bekliyor.",
}]
STEPS[13]["newInstrument"] = "DEPENDS_ON_PARAMETER"

# Q13 · Adım 21 + Stille
review(21, 13, "B + Stille", "Stille penset ile doku tutulur, Metzenbaum veya monopolar ile yapışıklık ayrılır.")
resolve_conflicts(21, 13, "Klinik teyit (S13): Excalidraw (B) + Stille penset eklendi.")
STEPS[21]["inst"].insert(2, I("FORCEPS_STILLE_NON_TOOTHED_15", "SUPPORT", note="Dokuyu tutmak için"))

# Q15 · Adım 23 klemp sayısı ve tipi damara göre
review(23, 15, "B + dinamik klemp", "Klemp sayısı damar sayısına göre değişir; tip damar çapına göre (S30).")
resolve_conflicts(23, 15, "Klinik teyit (S15, S30): Excalidraw düzeni (Semken, koter, portegü) korunur; klemp adedi damar sayısı, tipi damar çapı ile belirlenir.")
STEPS[23]["inst"] = [I("CLAMP_CRILE_CURVED_14", note="Varsayılan: orta çaplı damar; adet ve tip MESO_VESSELS'e göre"),
                     I("LIGATURE_SURGEON_CHOICE", "SUPPORT"), I("FORCEPS_SEMKEN_NON_TOOTHED_15_5", "ALTERNATIVE"),
                     I("ESU_MONOPOLAR_PEN", "ALTERNATIVE"), I("NEEDLE_HOLDER_DEBAKEY_18", "ALTERNATIVE", note="İğneli ligatürde")]
STEPS[23]["dynamicQuantity"] = {"parameter": "MESO_VESSELS", "rule": "Her damar için 1 hemostatik klemp",
                                "instrumentByCaliber": HEMOSTAT_BY_CALIBER}
STEPS[24]["inst"] = [I("SCISSORS_METZENBAUM_CURVED", note="Sete eklenecek (S29)"), I("CLAMP_CRILE_CURVED_14", "IN_USE", note="Adım 23'teki klempler")]
STEPS[41]["inst"].insert(0, I("CLAMP_MOSQUITO", "ALTERNATIVE", note="Küçük damar"))
STEPS[41]["inst"].insert(1, I("CLAMP_PEAN", "ALTERNATIVE", note="Büyük damar"))
STEPS[41]["selectionRule"] = {"by": "vesselCaliber", "instrumentByCaliber": HEMOSTAT_BY_CALIBER, "reviewQuestion": 30}

# Q20 · Adım 48
review(48, 20, "B veya Stille", "2 adet Crile eğri ya da Stille penset; hekim tercihi.")
resolve_conflicts(48, 20, "Klinik teyit (S20): 2 adet Crile eğri 14 cm veya Stille penset; hekim tercihi.")
STEPS[48]["inst"] = [I("CLAMP_CRILE_CURVED_14", "ALTERNATIVE", qty=2), I("FORCEPS_STILLE_NON_TOOTHED_15", "ALTERNATIVE")]

# Q21 · Adım 51
review(51, 21, "B")
resolve_conflicts(51, 21, "Klinik teyit (S21): Excalidraw (B) doğru.")

# Q23, Q24 · zorunluluk teyidi
for n in (27, 35, 36, 37):
    review(n, 23, "Zorunlu", "Güdük her vakada gömülür; çuval ağzı gibi: önce içe çevrilir, sonra ip sıkılarak büzülür.")
STEPS[27]["notes"] = ["Klinik teyit S23: güdük gömme her vakada yapılır (zorunlu)."]
for n in (42, 43, 53):
    review(n, 24, "Zorunlu", "Yıkama her vakada yapılır.")
review(29, 25, "Doğru", "Bağ güvenli değilse Adım 28'e dönülür.")

# Q26 · sayım uyuşmazlığı alt akışı (47 → 44 döngüsü yerine)
BRANCHES[47] = [{"when": "COUNT_MISMATCH", "goTo": "47a", "note": "Sayım uyuşmazlığı alt akışı"}]
review(47, 26, "Alt akış", "Önce eksik kalem tekrar sayılır; sürerse saha araması ve radyolojik görüntüleme.")

# Q27 · yıkama sonrası kanama ara adımı
BRANCHES[43] = [{"when": "BLEEDING_AFTER_IRRIGATION", "goTo": "43a", "note": "Ara hemostaz, sonra tekrar yıkama"}]
review(43, 27, "Ara adım", "Yıkamadan sonra kanama görülürse monopolar koterle durdurulur, tekrar yıkanır; Adım 40'a dönülmez ama hazırlıkları tekrarlanır.")
review(40, 27, "Adaptif", "Kanamanın olup olmayacağı dijital ikize göre AI/adaptif motor tarafından seçilebilir.")
STEPS[40]["adaptiveCondition"] = "BLEEDING_DETECTED"

SUBFLOWS = [
    {"id": "HEMOSTASIS_RECHECK", "name": "Yıkama sonrası kanama", "reviewQuestion": 27, "entryFrom": 43, "returnsTo": 42,
     "steps": [
        {"id": "43a", "name": "Ara hemostaz: kanamanın monopolar koter ile durdurulması", "action": "HEMOSTASIS", "target": "BLEEDING_SITES",
         "performedBy": ["SURGEON"], "instrument": "ESU_MONOPOLAR_PEN", "energyMode": "COAG",
         "instruments": [I("ESU_MONOPOLAR_PEN", note="Koagülasyon modunda"), I("SUCTION_TIP_YANKAUER", "STANDBY"), I("IRRIGATION_SYRINGE", "STANDBY"),
                         I("RADIOPAQUE_LAP_SPONGE", "STANDBY"), I("STERILE_GAUZE_SPONGE", "STANDBY")],
         "notes": ["Adım 40'taki hazırlıklar (aspiratör, yıkama enjektörü, radyopak kompres, spanç) tekrarlanır."],
         "nextStep": 42, "branches": []},
     ]},
    {"id": "COUNT_DISCREPANCY", "name": "Sayım uyuşmazlığı", "reviewQuestion": 26, "entryFrom": 47, "returnsTo": 48,
     "steps": [
        {"id": "47a", "name": "Eksik malzemenin tekrar sayılması", "action": "COUNT", "target": "MISSING_ITEM",
         "performedBy": ["SCRUB", "CIRCULATOR"], "instrument": None, "instruments": [],
         "nextStep": "47b", "branches": [{"when": "ITEM_FOUND_ON_RECOUNT", "goTo": 47, "note": "Sayım hatasıydı; doğrulamaya dön"}]},
        {"id": "47b", "name": "Saha araması", "action": "SEARCH", "target": "SURGICAL_FIELD",
         "performedBy": ["SURGEON", "SCRUB", "CIRCULATOR"], "instrument": "HAND",
         "instruments": [I("HAND", note="Saha, örtüler, atık kovası"), I("SUCTION_TIP_YANKAUER", "STANDBY"), I("RETRACTOR_FARABEUF_15_SET", "IN_USE")],
         "nextStep": "47d", "branches": [{"when": "ITEM_FOUND_IN_FIELD", "goTo": "47c"}]},
        {"id": "47c", "name": "Bulunan malzemenin sayıma eklenmesi", "action": "COUNT", "target": "ALL_COUNTS",
         "performedBy": ["SCRUB", "CIRCULATOR"], "instrument": None, "instruments": [], "nextStep": 47, "branches": []},
        {"id": "47d", "name": "Radyolojik görüntüleme", "action": "IMAGING", "target": "PATIENT",
         "performedBy": ["SURGEON", "TEAM"], "instrument": None, "instruments": [],
         "nextStep": "47f", "branches": [{"when": "ITEM_FOUND_ON_IMAGING", "goTo": "47e"}]},
        {"id": "47e", "name": "Malzemenin hastadan çıkarılması; peritondan itibaren yeniden kapatma", "action": "RETRIEVE", "target": "MISSING_ITEM",
         "performedBy": ["SURGEON"], "instrument": "HAND", "instruments": [I("HAND"), I("RETRACTOR_FARABEUF_15_SET", "STANDBY")],
         "notes": ["Klinik teyit S26: görüntülemede bulunursa hasta tekrar açılır ve peritondan itibaren yeniden kapatılır."],
         "nextStep": 48, "branches": []},
        {"id": "47f", "name": "Görüntülemede bulunamadı: kayıt ve cerrah kararı", "action": "RECORD", "target": "PATIENT_RECORD",
         "performedBy": ["SURGEON", "CIRCULATOR"], "instrument": None, "instruments": [],
         "pendingClinicalConfirmation": ["Q-A5"], "notes": ["Kaynakta tanımlı değil; varsayılan olarak olay kaydı yapılıp kapanışa devam edilir."],
         "nextStep": 48, "branches": []},
     ]},
]

# Q28 · ameliyat öncesi notları (build.py PREOP'a uygular)
PREOP_NOTES = {
    "PRE03": "Klinik teyit S28: koter cihazının hazırlığı boyamadan önce yapılır.",
    "PRE07": "Klinik teyit S28: koter kalemi ve aspiratör hazırlığı hasta örtüldükten sonra steril olarak yapılır.",
    "PRE08": "Klinik teyit S28: koter kalemi ve aspiratör bağlantısı hasta örtüldükten sonra steril olarak yapılır.",
}

# ---------------------------------------------------------------- doğru uygulama metni düzeltmeleri
PRACTICE_OVERRIDES = {
    1: "Hekimin tercihine göre 10 veya 15 numaralı bistüri ucu 3 numaralı bistüri sapına güvenli şekilde takılır. Bistüri, sap kısmı cerraha dönük olacak şekilde uzatılır.",
    8: "Peritonun kontrollü biçimde tutulup yükseltilmesi için cerrahın tercihine göre Stille dişsiz penset 15 cm veya DeBakey diseksiyon penseti hazırlanır. Pensetin uç uyumu, yüzeyi, bütünlüğü ve sterilitesi kontrol edilir; güvenli biçimde uzatılır.",
    38: "Appendiks, tutulduğu Babcock klemp 16 cm ile birlikte sirkülenin hazırladığı %10 formaldehitli patoloji kabına asepsi bozulmadan bırakılır. Sirküle Babcock klempi kaptan alır ve kirli alanda tutar; alet ameliyat odasından çıkmaz ve kapanış sayımında sayılır.",
    50: "Kas tabakası için cerrahın istediği emilebilir sütür (1, 0 veya 2/0) hazırlanır; 2/0'dan ince sütür kullanılmaz. Scrub sütürün türünü, numarasını ve emilebilir olduğunu sözlü olarak doğrular, paket bütünlüğünü ve iğne-sütür bağlantısını kontrol eder, TC De Bakey portegü 18 cm'ye hazırlayıp güvenli biçimde uzatır. Yeni iğne sayım kaydına eklenir.",
}

# ---------------------------------------------------------------- hata senaryosu bayrakları
# SUPERSEDED: klinik teyitle çelişiyor, RAG'a girmez · CONDITIONAL: yalnızca belirtilen durumda geçerli · PENDING: teyit bekliyor
SCENARIO_FLAGS = {}
for k in range(1, 7):
    SCENARIO_FLAGS[f"S08-E{k}"] = {"status": "SUPERSEDED", "reviewQuestion": 9,
                                   "note": "Senaryo Crile klemp üzerine yazılmış; klinik teyitte periton penset ile tutuluyor. Yeni senaryo gerekiyor (Q-A3)."}
SCENARIO_FLAGS["S50-E3"] = {"status": "SUPERSEDED", "reviewQuestion": 5, "note": "2/0 sütür klinik teyitte kabul ediliyor."}
for e in ("S50-E1", "S50-E2"):
    SCENARIO_FLAGS[e] = {"status": "PENDING", "reviewQuestion": 5, "note": "Prolen'in kas tabakasında kullanımı teyit bekliyor (Q-A1)."}
for e in ("S48-E1", "S48-E2", "S48-E3", "S48-E4"):
    SCENARIO_FLAGS[e] = {"status": "CONDITIONAL", "reviewQuestion": 20, "applicableWhen": "Cerrah Crile klemp eğri 14 cm seçtiyse"}
SCENARIO_FLAGS["S13-E1"] = {"status": "CONDITIONAL", "reviewQuestion": 11,
                            "applicableWhen": "Vücut tipi kuralı ek ekartör gerektirmiyorsa (PATIENT_BODY_TYPE)"}
SCENARIO_FLAGS["S23-E1"] = {"status": "CONDITIONAL", "reviewQuestion": 15, "applicableWhen": "Orta çaplı damar için"}
SCENARIO_FLAGS["S23-E2"] = {"status": "CONDITIONAL", "reviewQuestion": 15,
                            "applicableWhen": "MESO_VESSELS iki damar içeriyorsa; adet damar sayısına göre değişir"}

# ---------------------------------------------------------------- yeni açık sorular
OPEN_QUESTIONS = [
    {"id": "Q-A1", "step": 50, "question": "Cevapta 'Prolen ve Vicryl emilebilir' denmiş. Prolen (polipropilen) emilmeyen bir iplik olarak bilinir. Kas tabakasında Prolen kullanılabilir mi, yoksa yalnızca Vicryl mi? Önerdiğiniz emilebilir/emilmeyen iplik listesini de gönderebilir misiniz?"},
    {"id": "Q-A2", "step": 50, "question": "'1, 0 veya 2' derken 2 numara değil 2/0 kastedildi mi? (Modelde 2/0 olarak işlendi; 2/0'dan ince iplik kullanılmıyor.)"},
    {"id": "Q-A3", "step": 8, "question": "Adım 8'in 6 hata senaryosu Crile klemp üzerine yazılmıştı ve geçersiz oldu. Stille/DeBakey penset için yeni hata senaryolarını kim yazacak? (Ben taslak çıkarabilirim, onayınız gerekir.)"},
    {"id": "Q-A4", "step": 13, "question": "Vücut tipine göre ekartör: zayıf hastada Farabeuf veya Langenbeck, normal kiloda Langenbeck yazıyor. Normal kilolu hastada Adım 11'de yine Farabeuf verilip 13'te Langenbeck mi ekleniyor? Kilolu hastada 'daha uzun uçlu ekartör' tam olarak hangisi (Richardson mı, uzun Langenbeck mi)?"},
    {"id": "Q-A5", "step": 47, "question": "Eksik malzeme radyolojik görüntülemede de bulunamazsa ne yapılıyor? Ayrıca sayım periton kapanmadan önce yapıldığı için 'tekrar açma' kapanış başladıktan sonraki bir sayımı mı ifade ediyor; cilt kapanmadan önce ikinci bir sayım var mı?"},
    {"id": "Q-A6", "step": 43, "question": "Yıkama sonrası kanama döngüsü en fazla kaç kez tekrarlanabilir? (Modelde varsayılan 2.)"},
]
