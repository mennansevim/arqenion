# Açık Apendektomi — RAG + Koşullu Akış Paketi (v2.0.0)

v2, klinik ekibin 30 soruya verdiği cevapları (akis_sorulari.md, 2026-10-07) modele işler. Kaynaklar arasındaki 21 farkın hepsi kapandı. Klinik kararlar `clinical_review.py` içinde soru numarasıyla tutulur; Excalidraw yeniden derlendiğinde kaybolmaz.

## Dosyalar

| Dosya | Ne için | Embed edilir mi? |
|---|---|---|
| `open-appendectomy-v2.json` | Master model (60 adım, 2 alt akış, 9 ameliyat öncesi bölüm, 276 senaryo) | Hayır |
| `open-appendectomy-v2.chunks.jsonl` | Vektör DB'ye yüklenecek 410 parça | **Evet** |
| `open-appendectomy-v2.graph.json` | Akış motoru için kompakt graf | Hayır |
| `open-appendectomy-v2.full.mmd` | Tüm dallar ve alt akışlar dahil Mermaid | — |
| `flow_engine.py` | Koşul + hasta parametresi → yol, beklenen aletler, Mermaid, LLM araç tanımı | — |
| `clinical_review.py` | Klinik teyit kararları (model_data.py'nin üstüne yazar) | — |
| `model_data.py`, `build.py`, `parse_excalidraw.py`, `validate.py`, `rag_export.py` | Üretim ve doğrulama | — |
| `acik-sorular-v2.md` | Klinik ekibe gidecek 6 yeni soru | — |

## v1 → v2 değişiklikleri

**Alet kararları**
- **Adım 1:** 10 ve 15 numara bistüri ucu ikisi de kabul edilir (hekim tercihi).
- **Adım 8:** Periton Stille veya DeBakey penseti ile tutulur. Excalidraw'daki 6 Crile senaryosu geçersiz sayıldı.
- **Adım 9:** Bistüri ucu değiştirilir. Değiştirilmezse enfeksiyonun gelişip gelişmeyeceğini adaptif motor seçer.
- **Adım 13:** Vücut tipine göre ekartör kuralı eklendi (`PATIENT_BODY_TYPE`).
- **Adım 21:** Stille penset eklendi.
- **Adım 23:** Klemp adedi damar sayısına, klemp tipi damar çapına göre belirlenir (`MESO_VESSELS`):
  - küçük damar → mosquito,
  - orta damar → Crile,
  - büyük damar → pean.
- **Adım 30:** İşaret pensi Crile klemptir; Babcock işaret için kullanılmaz.
- **Adım 38:** Babcock appendiksle birlikte patoloji kabına bırakılır. Sirküle onu alıp kirli alanda tutar; alet sayımda kalır.
- **Adım 48:** Crile eğri ×2 ya da Stille penset (hekim tercihi).
- **Adım 50:** Emilebilir sütür zorunlu; kalınlık 1, 0 veya 2/0. Prolen'in durumu teyit bekliyor (Q-A1).
- **Katalog:** Metzenbaum makas sete ekleniyor. Sütürler ve serum fizyolojik haricen açılan sarf malzemesi. Sütürlerde materyal ve emilebilirlik bilgisi var.

**Akış**
- **Sayım uyuşmazlığı alt akışı (47a–47f):** 47→44 döngüsünün yerini aldı.
  1. Önce eksik kalem tekrar sayılır.
  2. Bulunamazsa saha araması yapılır.
  3. Sahada da yoksa radyolojik görüntüleme yapılır.
  4. Görüntülemede bulunursa malzeme çıkarılır ve peritondan itibaren yeniden kapatılır.
- **Yıkama sonrası kanama ara adımı (43a):** Kanama monopolar koter ile durdurulur, Adım 40'ın hazırlıkları tekrarlanır ve yeniden yıkamaya (Adım 42) dönülür. Bu döngü en fazla 2 kez çalışır.
- **Zorunluluk teyidi:** Güdük gömme (27, 35–37) ve yıkama (42, 43, 53) her vakada yapılır.

## Koşul kaynakları

Her koşulun bir `source` alanı var:

| source | Kim belirler | Örnek |
|---|---|---|
| `SCENARIO` | Senaryo, seans başında | Yapışıklık (scenarios.json `hasAdhesion`), yetersiz görüş |
| `ADAPTIVE` | Adaptive Training Engine, kursiyerin dijital ikizine göre; AI öneri verebilir | Kanama, bağın güvensiz olması, eksik malzemenin yeri, enfeksiyon |
| `RUNTIME` | Kursiyerin olayları | Sayım uyuşmazlığı |

Klinik ekip kanama ve enfeksiyon gibi olayların gerçekleşip gerçekleşmeyeceğinin AI'a bırakılmasını istedi. Bu, "doğru/yanlış kararını motor verir" ilkesini bozmuyor:

- Seçim yalnızca izin verilen değerler (true/false) arasından yapılır.
- Seçim motora girdi olarak verilir; yolu yine motor yürür.
- Her seçim kayda geçer.
- Sınav modunda bu koşullar senaryoda sabitlenir.

`walk()` sonucundaki `adaptiveDecisions`, yolda karar bekleyen adaptif koşulları listeler. Adaptive Engine'in neye karar vermesi gerektiği buradan okunur.

## Akış motoru

```python
from flow_engine import FlowEngine
fe = FlowEngine("open-appendectomy-v2.graph.json")
r = fe.walk(
    {"ADHESIONS_PRESENT": True,
     "BLEEDING_AFTER_IRRIGATION": [True, False],   # 1. yıkamada kanama var, 2.'de yok
     "COUNT_MISMATCH": True, "ITEM_FOUND_IN_FIELD": True},
    parameters={"PATIENT_BODY_TYPE": "OBESE",
                "MESO_VESSELS": [{"caliber": "SMALL"}, {"caliber": "LARGE"}]})
r["path"]                    # [..., 42, 43, '43a', 42, 43, 44, ..., 47, '47a', '47b', '47c', 47, 48, ...]
r["expectedInstruments"]["23"]   # klempler: mosquito x1, pean x1
r["adaptiveDecisions"]       # karar verilmemiş adaptif koşullar
print(fe.mermaid(r, 40, 49))
```

CLI kullanımı:

```bash
python3 flow_engine.py --cond BLEEDING_AFTER_IRRIGATION=true,false --param PATIENT_BODY_TYPE=OBESE --from 38 --to 50
python3 flow_engine.py --full
```

LLM araç tanımı `fe.TOOL_SCHEMA` içinde; koşul listesi graph.json'dan otomatik üretiliyor.

## RAG notları

- `reviewStatus=SUPERSEDED` olan 7 senaryo RAG'a girmez: S08-E1…E6 ve S50-E3.
- `CONDITIONAL` (7) ve `PENDING` (2) senaryolar girer. Durumları metinde ve `metadata.reviewStatus` alanında yazar.
- Retrieval filtresine `reviewStatus != "PENDING"` eklemek, teyit gelene kadar Prolen'li senaryoları dışarıda tutar.
- Alt akış adımları `chunkType=subflow_step` ile girer. `metadata.step` alanı ana adım numarasıdır (47a → 47).

## Yeniden üretim

```bash
python3 build.py operion.excalidraw apendektomi.pdf open-appendectomy-v2.json
python3 validate.py open-appendectomy-v2.json      # şu an: 0 hata, 1 uyarı (Adım 8'de yeni senaryo bekleniyor)
python3 rag_export.py open-appendectomy-v2.json
```

## Uyarı

Bu içerik denetimli klinik simülasyon ve eğitim içindir. `acik-sorular-v2.md` dosyasındaki 6 soru cevaplanana kadar Adım 8, 13, 43, 47 ve 50'deki ilgili kısımlar "teyit bekliyor" olarak işaretli kalır.
