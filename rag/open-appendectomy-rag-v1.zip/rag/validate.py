import json,sys
m=json.load(open(sys.argv[1])); c=m['catalogs']; err=[]
ids={s['step'] for s in m['steps']}
for s in m['steps']:
    if s['action'] not in c['actions']: err.append((s['step'],'action'))
    if s['target'] not in c['targets']: err.append((s['step'],'target'))
    if s['instrument'] and s['instrument'] not in c['instruments']: err.append((s['step'],'instrument'))
    for i in s['instruments']:
        if i['code'] not in c['instruments']: err.append((s['step'],i['code']))
        if i['usage'] not in c['instrumentUsage']: err.append((s['step'],i['usage']))
    for r in s['performedBy']:
        if r not in c['roles']: err.append((s['step'],r))
    nx=[s['nextStep']]+[b['goTo'] for b in s['branches']]
    for x in nx:
        if x is not None and x not in ids: err.append((s['step'],'next',x))
    for b in s['branches']:
        if b['when'] not in c['conditions']: err.append((s['step'],b['when']))
    if not s['scrub']['errorScenarios']: err.append((s['step'],'noScenarios'))
# reachability from step 1 and every step reaches 60
adj={s['step']:[x for x in [s['nextStep']]+[b['goTo'] for b in s['branches']] if x] for s in m['steps']}
seen=set(); st=[1]
while st:
    v=st.pop()
    if v in seen: continue
    seen.add(v); st+=adj[v]
if seen!=ids: err.append(('unreachable',ids-seen))
def reaches(v,goal=60,vis=None):
    vis=vis or set()
    if v==goal: return True
    vis.add(v); return any(reaches(w,goal,vis) for w in adj[v] if w not in vis)
bad=[v for v in ids if not reaches(v)]
if bad: err.append(('noPathTo60',bad))
# conditional steps must be targeted by a branch
targets={b['goTo'] for s in m['steps'] for b in s['branches']}
for s in m['steps']:
    if s['isConditional'] and s['step'] not in targets and not any(adj[p]==[s['step']] for p in adj if p!=s['step'] and next(x for x in m['steps'] if x['step']==p)['isConditional']):
        err.append((s['step'],'conditional-not-branched'))
pre=m['preoperative']; assert pre[-1]['nextStep']==1
print('errors:',err or 'none')
