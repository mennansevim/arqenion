# Açık Apendektomi — RAG + Koşullu Akış Paketi (v1.0.0)

## Dosyalar

| Dosya | Ne için | Embed edilir mi? |
|---|---|---|
| `open-appendectomy-v1.json` | Kaynak (master) model. Her şey buradan türetilir | Hayır |
| `open-appendectomy-v1.chunks.jsonl` | Vektör DB'ye yüklenecek 404 parça (`id`, `text`, `metadata`) | **Evet** |
| `open-appendectomy-v1.graph.json` | Akış motoru için kompakt graf | Hayır |
| `flow_engine.py` | Koşullara göre yolu hesaplar, Mermaid üretir, LLM araç tanımını içerir | — |
| `rag_export.py` | Master JSON'dan chunks + graph üretir | — |
| `build.py`, `model_data.py`, `parse_excalidraw.py`, `validate.py` | Master JSON'u kaynak dosyalardan yeniden üretir ve doğrular | — |

## Temel fikir: arama ile yol bulmayı ayırmak

```
Kullanıcı sorusu
   │
   ├─► LLM: koşulları çıkarır  ──►  draw_surgical_flow(conditions, from, to)  ──►  flow_engine (deterministik)
   │                                                                                 │  path + mermaid
   └─► Retriever: metadata filtresi + vektör arama  ──►  ilgili step / error chunk'ları
                                                                                     ▼
                                           LLM: diyagram + kaynaklı açıklama
```

Akışı, yani hangi adımın hangi koşulda geldiğini, LLM'in chunk'lardan çıkarmasına izin verme. Vektör araması adımları atlayabilir ya da sırayı karıştırabilir. Yolu `flow_engine` hesaplar. RAG yalnızca adımların içeriğini (aletler, scrub uygulaması, hata senaryoları) getirmek için kullanılır.

## Chunk tipleri ve metadata

| chunkType | Adet | Kullanım |
|---|---|---|
| `step` | 60 | Adım özeti: işlem, hedef, aletler, koşul, sonraki adım, kaynak farkları |
| `error_scenario` | 276 | Tek bir hata senaryosunun tamamı |
| `preoperative` | 9 | PRE01–PRE09 |
| `preop_error_checklist` | 14 | Koter ve aspiratör hazırlığındaki hata/sonuç listeleri |
| `instrument` | 44 | Alet ve kullanıldığı adımlar |
| `global_rules` | 1 | Genel kurallar |

Filtrelenebilir metadata alanları: `step`, `phaseId`, `action`, `target`, `instruments[]`, `roles[]`, `isMandatory`, `isConditional`, `condition`, `isDecisionPoint`, `hasSourceConflict`, `scenarioId`.

Öneri: Akış motoru yolu döndürdükten sonra `metadata.step IN path` filtresiyle retrieval yap. Böylece atlanan bir dalın (ör. yapışıklık yokken Adım 20–21) içeriği cevaba karışmaz.

Chunk boyutu ortalama ~2.000, en fazla ~7.100 karakter. Her chunk tek bir anlamsal birim olduğu için ayrıca bölmeye gerek yok.

## Koşullar

| Kod | Değerlendirildiği adım | true olursa |
|---|---|---|
| `EXPOSURE_INSUFFICIENT` | 11 | 12 (Roux) uygulanır |
| `ADHESIONS_PRESENT` | 19 | 20–21 uygulanır |
| `LIGATURE_NOT_SECURE` | 29 | 28'e bir kez geri dönülür |
| `BLEEDING_DETECTED` | 40 | 41 (hemostaz) uygulanır |
| `COUNT_MISMATCH` | 47 | 44'e bir kez geri dönülüp sayım tekrarlanır |

Belirtilmeyen koşul `false` kabul edilir.

## Kullanım

```bash
python3 flow_engine.py --cond ADHESIONS_PRESENT=true --from 14 --to 30   # Mermaid
python3 flow_engine.py --cond BLEEDING_DETECTED=true --json               # yol listesi
python3 flow_engine.py --full                                             # tüm dallar
```

```python
from flow_engine import FlowEngine, TOOL_SCHEMA
fe = FlowEngine("open-appendectomy-v1.graph.json")
# TOOL_SCHEMA'yı LLM'e araç olarak ver; çağrı geldiğinde:
result = fe.run_tool({"conditions": {"ADHESIONS_PRESENT": True}, "from_step": 14, "to_step": 30})
# result -> {"path": [...], "skippedSteps": [...], "mermaid": "flowchart TD ..."}
```

## Örnek sistem promptu (özet)

> Açık apendektomi akışlarını yalnızca `draw_surgical_flow` aracıyla çiz; adım sırasını kendin üretme.
> Kullanıcının anlattığı durumdan koşulları çıkar (yapışıklık, kanama, bağ güvensizliği, sayım uyumsuzluğu, yetersiz görüş). Emin değilsen kullanıcıya sor.
> Adım detaylarını yalnızca getirilen chunk'lara dayanarak açıkla ve `step` / `scenarioId` numarasıyla kaynak göster.
> `hasSourceConflict=true` olan adımlarda PDF ile Excalidraw'ın farklı olduğunu belirt.

## Yeni versiyon

Excalidraw ya da PDF değişirse:

```bash
python3 build.py operion.excalidraw apendektomi.pdf open-appendectomy-v2.json
python3 validate.py open-appendectomy-v2.json
python3 rag_export.py open-appendectomy-v2.json
```

Elle kodlanan alanlar (işlem, alet, hedef, dallanmalar, kaynak farkları) `model_data.py` içindedir. Sürüm numarasını orada ve `build.py` içinde artır. Chunk `id`'leri `open-appendectomy@<versiyon>:...` biçimindedir; bu sayede eski ve yeni sürüm vektör DB'de karışmaz.

## Uyarı

Kaynak metinler "denetimli klinik simülasyon ve eğitim" amaçlıdır. 21 adımda kaynaklar arasında alet farkı vardır (Excalidraw esas alındı). Gerçek klinik karar desteğinde kullanmadan önce bu farklar klinik ekip tarafından onaylanmalıdır.
