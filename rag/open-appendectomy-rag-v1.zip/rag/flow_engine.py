# -*- coding: utf-8 -*-
"""Koşula göre akış hesaplama ve çizim (deterministik — LLM yolu kendisi uydurmaz).

Python:
    from flow_engine import FlowEngine
    fe = FlowEngine("open-appendectomy-v1.graph.json")
    r = fe.walk({"ADHESIONS_PRESENT": True, "BLEEDING_DETECTED": False})
    print(fe.mermaid(r, from_step=14, to_step=30))

CLI:
    python3 flow_engine.py --cond ADHESIONS_PRESENT=true --cond BLEEDING_DETECTED=true --from 14 --to 45
    python3 flow_engine.py --full            # tüm dallarıyla genel akış
"""
import json, argparse, re

# LLM function-calling için araç tanımı (Anthropic / OpenAI uyumlu JSON Schema)
TOOL_SCHEMA = {
    "name": "draw_surgical_flow",
    "description": "Açık apendektomi akışını verilen klinik koşullara göre hesaplar ve Mermaid diyagramı döndürür. Koşul belirtilmezse false kabul edilir.",
    "input_schema": {
        "type": "object",
        "properties": {
            "conditions": {
                "type": "object",
                "description": "Koşul kodu -> true/false",
                "properties": {
                    "EXPOSURE_INSUFFICIENT": {"type": "boolean", "description": "Farabeuf ile görüş yetersiz"},
                    "ADHESIONS_PRESENT": {"type": "boolean", "description": "Yapışıklık var"},
                    "LIGATURE_NOT_SECURE": {"type": "boolean", "description": "Appendiks kökü bağı güvensiz (bir kez yeniden bağlanır)"},
                    "BLEEDING_DETECTED": {"type": "boolean", "description": "Kanama saptandı"},
                    "COUNT_MISMATCH": {"type": "boolean", "description": "Sayım uyumsuz (bir kez yeniden sayılır)"},
                },
                "additionalProperties": False,
            },
            "from_step": {"type": "integer", "minimum": 1, "maximum": 60},
            "to_step": {"type": "integer", "minimum": 1, "maximum": 60},
            "include_preop": {"type": "boolean", "default": False},
            "show_skipped": {"type": "boolean", "default": True, "description": "Atlanan koşullu adımları soluk göster"},
        },
    },
}


class FlowEngine:
    def __init__(self, graph_path):
        g = json.load(open(graph_path))
        self.g = g
        self.nodes = {n["id"]: n for n in g["nodes"]}
        self.phase = {p["id"]: p["name"] for p in g["phases"]}

    def walk(self, conditions=None, include_preop=False, max_loop=1):
        """Koşullara göre yürür. Geri dönüşlü dallar (29→28, 47→44) koşul true ise en fazla max_loop kez alınır."""
        cond = {k: bool(v) for k, v in (conditions or {}).items()}
        unknown = set(cond) - set(self.g["conditions"])
        if unknown:
            raise ValueError(f"Bilinmeyen koşul: {unknown}")
        path, edges, taken = [], [], {}
        cur = self.g["entry"] if include_preop else 1
        guard = 0
        while cur is not None:
            guard += 1
            assert guard < 500, "döngü"
            path.append(cur)
            n = self.nodes[cur]
            nxt, label = n["next"], None
            for b in n.get("branches", []):
                loop_back = isinstance(b["goTo"], int) and b["goTo"] <= cur
                if cond.get(b["when"]) and (not loop_back or taken.get((cur, b["when"]), 0) < max_loop):
                    taken[(cur, b["when"])] = taken.get((cur, b["when"]), 0) + 1
                    nxt, label = b["goTo"], b["when"]
                    break
            if nxt is not None:
                edges.append((cur, nxt, label))
            cur = nxt
        visited = set(path)
        skipped = [n["id"] for n in self.g["nodes"] if isinstance(n["id"], int) and n["id"] not in visited]
        return {"conditions": cond, "path": path, "edges": edges, "skippedSteps": skipped,
                "stepCount": sum(1 for p in path if isinstance(p, int))}

    # ---------- Mermaid ----------
    @staticmethod
    def _nid(x):
        return f"S{x}" if isinstance(x, int) else str(x)

    @staticmethod
    def _esc(t):
        return re.sub(r'["\[\]{}()<>]', "", t)

    def _shape(self, n):
        lbl = self._esc((f"{n['id']}. " if isinstance(n["id"], int) else f"{n['id']} ") + n["label"])
        if n.get("instrument") and n["instrument"] != "HAND":
            lbl += f"<br/><small>{n['instrument']}</small>"
        i = self._nid(n["id"])
        if n["kind"] == "decision":
            return f'{i}{{"{lbl}"}}'
        if n["kind"] == "preop":
            return f'{i}(["{lbl}"])'
        return f'{i}["{lbl}"]'

    def mermaid(self, result, from_step=None, to_step=None, show_skipped=True, by_phase=True):
        lo, hi = from_step or -1, to_step or 10**9
        inr = lambda x: (not isinstance(x, int)) or lo <= x <= hi
        path = [p for p in result["path"] if inr(p)]
        shown = list(dict.fromkeys(path))
        skipped = [s for s in result["skippedSteps"] if inr(s)] if show_skipped else []
        L = ["flowchart TD",
             "classDef cond fill:#fff4d6,stroke:#c98a00;",
             "classDef dec fill:#e6f0ff,stroke:#2f6fd6;",
             "classDef skip fill:#f2f2f2,stroke:#bbb,color:#999,stroke-dasharray:4 3;",
             "classDef pre fill:#eef7ee,stroke:#3a8a3a;"]
        allids = shown + skipped
        if by_phase:
            groups = {}
            for x in allids:
                n = self.nodes[x]
                groups.setdefault(n.get("phaseId", "PREOP"), []).append(x)
            for gid, xs in groups.items():
                title = self.phase.get(gid, "Ameliyat öncesi")
                L.append(f'subgraph {gid}["{self._esc(title)}"]')
                L += ["  " + self._shape(self.nodes[x]) for x in sorted(xs, key=lambda v: (isinstance(v, int), v if isinstance(v, int) else 0))]
                L.append("end")
        else:
            L += [self._shape(self.nodes[x]) for x in allids]
        for a, b, lab in dict.fromkeys(map(tuple, result["edges"])):
            if inr(a) and inr(b):
                L.append(f"{self._nid(a)} -->|{lab}| {self._nid(b)}" if lab else f"{self._nid(a)} --> {self._nid(b)}")
        for s in skipped:  # atlanan dalı kesikli göster
            for n in self.g["nodes"]:
                for br in n.get("branches", []):
                    if br["goTo"] == s and inr(n["id"]):
                        L.append(f"{self._nid(n['id'])} -.->|{br['when']}=false| {self._nid(s)}")
        for x in allids:
            n = self.nodes[x]
            cls = "skip" if x in skipped else {"decision": "dec", "conditional": "cond", "preop": "pre"}.get(n["kind"])
            if cls:
                L.append(f"class {self._nid(x)} {cls};")
        return "\n".join(L)

    def full_mermaid(self):
        """Tüm dallar dahil genel akış."""
        res = {"path": [n["id"] for n in self.g["nodes"] if isinstance(n["id"], int)], "skippedSteps": [], "edges": []}
        for n in self.g["nodes"]:
            if not isinstance(n["id"], int): continue
            if n["next"] is not None:
                res["edges"].append((n["id"], n["next"], "else" if n["branches"] else None))
            for b in n["branches"]:
                res["edges"].append((n["id"], b["goTo"], b["when"]))
        return self.mermaid(res)

    def run_tool(self, args):
        """LLM araç çağrısını karşılar."""
        r = self.walk(args.get("conditions"), include_preop=args.get("include_preop", False))
        return {"path": r["path"], "skippedSteps": r["skippedSteps"], "stepCount": r["stepCount"],
                "mermaid": self.mermaid(r, args.get("from_step"), args.get("to_step"), args.get("show_skipped", True))}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--graph", default="open-appendectomy-v1.graph.json")
    ap.add_argument("--cond", action="append", default=[], help="KOD=true|false")
    ap.add_argument("--from", dest="frm", type=int)
    ap.add_argument("--to", type=int)
    ap.add_argument("--preop", action="store_true")
    ap.add_argument("--full", action="store_true")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    fe = FlowEngine(a.graph)
    if a.full:
        print(fe.full_mermaid()); raise SystemExit
    conds = {k: v.lower() in ("1", "true", "evet", "yes") for k, v in (c.split("=") for c in a.cond)}
    r = fe.walk(conds, include_preop=a.preop)
    if a.json:
        print(json.dumps(r, ensure_ascii=False, indent=1))
    else:
        print(fe.mermaid(r, a.frm, a.to))
