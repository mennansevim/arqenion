# -*- coding: utf-8 -*-
"""open-appendectomy-v1.json -> RAG çıktıları
  1) open-appendectomy-v1.chunks.jsonl : vektör DB'ye yüklenecek parçalar (text + metadata)
  2) open-appendectomy-v1.graph.json   : akış motoru için kompakt graf (embed EDİLMEZ)
Kullanım: python3 rag_export.py open-appendectomy-v1.json
"""
import json, sys, os

SRC = sys.argv[1]
base = os.path.splitext(SRC)[0]
m = json.load(open(SRC))
C = m["catalogs"]
VER = m["procedure"]["version"]
PROC = m["procedure"]["id"]
phase_name = {p["id"]: p["name"] for p in m["phases"]}

def inst_name(code): return C["instruments"][code]["name"]
def role_names(rs): return ", ".join(C["roles"][r] for r in rs)

def bl(items, prefix="- "):
    out = []
    for it in items:
        if isinstance(it, dict):  # {category, items} grubu
            if it.get("category"): out.append(f"{prefix}{it['category']}:")
            out += [f"  {prefix}{x}" for x in it["items"]]
        else:
            out.append(f"{prefix}{it}")
    return "\n".join(out)

chunks = []
def add(cid, ctype, text, **meta):
    md = {"procedure": PROC, "version": VER, "chunkType": ctype}
    md.update({k: v for k, v in meta.items() if v is not None})
    chunks.append({"id": f"{PROC}@{VER}:{cid}", "text": text.strip(), "metadata": md})

# ---- Adım chunk'ları ----
for s in m["steps"]:
    ph = phase_name[s["phaseId"]]
    L = [f"Açık apendektomi — Adım {s['step']}: {s['name']}",
         f"Faz: {ph} ({s['phaseId']})",
         f"İşlem: {C['actions'][s['action']]} [{s['action']}]",
         f"Hedef: {C['targets'][s['target']]} [{s['target']}]",
         f"Uygulayan: {role_names(s['performedBy'])}",
         f"Zorunlu: {'Evet' if s['isMandatory'] else 'Hayır'}"]
    if s["isConditional"]:
        L.append(f"Koşullu adım: yalnızca şu durumda uygulanır → {s['condition']['description']} [{s['condition']['code']}] (Adım {s['condition']['evaluatedAtStep']}'de değerlendirilir)")
    if s["isDecisionPoint"]:
        L.append("Karar noktası:" + "".join(f"\n- {C['conditions'][b['when']]} ise → Adım {b['goTo']}" for b in s["branches"]) + f"\n- Aksi halde → Adım {s['nextStep']}")
    else:
        L.append(f"Sonraki adım: {s['nextStep'] if s['nextStep'] else 'Yok (operasyon sonu)'}")
    L.append(f"Bu adımda yeni alet uzatılır mı: {'Evet' if s['newInstrumentHandover'] else 'Hayır'}")
    if s["instruments"]:
        L.append("Aletler:")
        for i in s["instruments"]:
            q = f" x{i['qty']}" if i["qty"] > 1 else ""
            n = f" — {i['note']}" if i.get("note") else ""
            L.append(f"- {inst_name(i['code'])}{q} ({C['instrumentUsage'][i['usage']]}){n}")
    for v in s.get("variants", []):
        L.append(f"Seçenek ({v['id']}): {' / '.join(v['options'])} — karar: {C['roles'][v['decidedBy']]}")
    for k, lbl in (("preconditions", "Ön koşul"), ("notes", "Not")):
        for x in s.get(k, []): L.append(f"{lbl}: {x}")
    if s.get("recordFields"): L.append("Kayıt alanları:\n" + bl(s["recordFields"]))
    L.append("Doğru scrub uygulaması: " + s["scrub"]["correctPractice"])
    if s["scrub"]["errorScenarios"]:
        L.append("Bu adımdaki hata senaryoları: " + "; ".join(f"{e['id']} {e['title']}" for e in s["scrub"]["errorScenarios"]))
    for c in s["sourceConflicts"]:
        L.append(f"Kaynak farkı ({c['field']}): PDF='{c['pdf']}' | Excalidraw='{c['excalidraw']}' | Karar: {c['resolution']}")
    add(f"step:{s['step']}", "step", "\n".join(L),
        step=s["step"], phaseId=s["phaseId"], phase=ph, action=s["action"], target=s["target"],
        instruments=[i["code"] for i in s["instruments"]], primaryInstrument=s["instrument"],
        roles=s["performedBy"], isMandatory=s["isMandatory"], isConditional=s["isConditional"],
        condition=s["condition"]["code"] if s["condition"] else None, isDecisionPoint=s["isDecisionPoint"],
        hasSourceConflict=bool(s["sourceConflicts"]))

    # ---- Hata senaryosu chunk'ları ----
    for e in s["scrub"]["errorScenarios"]:
        sg = e.get("signs", [])
        if isinstance(sg, dict):
            sg_txt = "\n".join(f"{'Ameliyat sırasında' if k=='intraoperative' else 'Ameliyat sonrasında'}:\n{bl(v)}" for k, v in sg.items())
        else:
            sg_txt = bl(sg)
        T = [f"Açık apendektomi — Adım {s['step']} ({s['name']}) — Hata senaryosu {e['id']}: {e['title']}",
             f"Faz: {ph}",
             f"Scrub'ın hatası: {e.get('scrubError','')}",
             "Olası komplikasyonlar:\n" + bl(e.get("possibleComplications", [])),
             "Belirtiler:\n" + sg_txt,
             "Scrub'ın sıralı çözüm yaklaşımı:\n" + "\n".join(f"{k+1}. {x}" for k, x in enumerate(e.get("resolutionSteps", []))),
             f"Vakanın devamı: {e.get('caseContinuation','')}",
             "Yönetim ve organizasyona etkisi:\n" + bl(e.get("organizationalImpact", []))]
        add(f"error:{e['id']}", "error_scenario", "\n".join(T),
            step=s["step"], phaseId=s["phaseId"], phase=ph, scenarioId=e["id"],
            instruments=[i["code"] for i in s["instruments"]], action=s["action"])

# ---- Ameliyat öncesi chunk'ları ----
for p in m["preoperative"]:
    L = [f"Açık apendektomi — Ameliyat öncesi {p['id']}: {p['name']}",
         f"Uygulayan: {role_names(p['performedBy'])}",
         f"Sonraki: {'Adım ' + str(p['nextStep']) if isinstance(p['nextStep'], int) else p['nextStep']}"]
    if p.get("tasks"): L.append("Yapılacaklar:\n" + bl(p["tasks"]))
    if p.get("responsibilityNote"): L.append("Sorumluluk: " + p["responsibilityNote"])
    for a in p.get("alternatives", []):
        L.append(f"{a['name']} ({a['id']}):\n" + bl(a["tasks"]))
    if p.get("selection"): L.append(p["selection"])
    if p.get("omissionRisks"): L.append("Uygun yapılmazsa:\n" + bl(p["omissionRisks"]))
    for sp in p.get("substeps", []):
        L.append(f"{sp['id']} {sp['name']}" + (f": {sp['task']}" if sp.get("task") else ""))
        if sp.get("isConditional"): L.append(f"  (Koşullu: {sp['condition']})")
        if sp.get("omissionRisks"): L.append("  Yapılmazsa:\n" + bl(sp["omissionRisks"], "  - "))
        for f in sp.get("forms", []):
            L.append(f"  Form: {f['form']} — kontrol edilmezse:")
            for r in f["omissionRisks"]:
                if isinstance(r, dict):
                    L.append(f"    * {r['item']}:\n" + bl(r["complications"], "      - "))
                else:
                    L.append(f"    - {r}")
    add(f"preop:{p['id']}", "preoperative", "\n".join(L), preopId=p["id"], roles=p["performedBy"])
    for k, ec in enumerate(p.get("errorChecklist", [])):
        T = [f"Açık apendektomi — Ameliyat öncesi {p['id']} ({p['name']}) — Hata kontrol listesi: {ec['task']}"]
        for er in ec["errors"]:
            T.append(f"- Hata: {er['error']}\n" + bl(er["consequences"], "    • "))
        add(f"preop:{p['id']}:check:{k+1}", "preop_error_checklist", "\n".join(T), preopId=p["id"], roles=p["performedBy"])

# ---- Genel kurallar + alet kataloğu ----
add("rules", "global_rules", "Açık apendektomi — Genel kurallar:\n" + "\n".join(f"- {r['id']}: {r['text']}" for r in m["globalRules"]))
usage = {}
for s in m["steps"]:
    for i in s["instruments"]: usage.setdefault(i["code"], []).append(s["step"])
for code, d in C["instruments"].items():
    st = sorted(set(usage.get(code, [])))
    add(f"instrument:{code}", "instrument",
        f"Alet: {d['name']} [{code}]\nKategori: {d['category']}\nKullanıldığı adımlar: {', '.join(map(str, st)) or '—'}",
        instrument=code, steps=st)

with open(base + ".chunks.jsonl", "w") as f:
    for c in chunks: f.write(json.dumps(c, ensure_ascii=False) + "\n")

# ---- Kompakt graf (akış motoru için) ----
graph = {
    "procedure": PROC, "version": VER,
    "conditions": C["conditions"],
    "entry": m["preoperative"][0]["id"],
    "nodes": [{"id": p["id"], "kind": "preop", "label": p["name"], "next": p["nextStep"]} for p in m["preoperative"]]
           + [{"id": s["step"], "kind": "decision" if s["isDecisionPoint"] else ("conditional" if s["isConditional"] else "step"),
               "label": s["name"], "phaseId": s["phaseId"], "action": s["action"], "instrument": s["instrument"],
               "target": s["target"], "roles": s["performedBy"], "mandatory": s["isMandatory"],
               "condition": s["condition"]["code"] if s["condition"] else None,
               "next": s["nextStep"], "branches": s["branches"]} for s in m["steps"]],
    "phases": [{"id": p["id"], "name": p["name"], "steps": p["steps"]} for p in m["phases"]],
}
json.dump(graph, open(base + ".graph.json", "w"), ensure_ascii=False, indent=1)

from collections import Counter
print("chunks:", len(chunks), dict(Counter(c["metadata"]["chunkType"] for c in chunks)))
L = [len(c["text"]) for c in chunks]
print("chars min/avg/max:", min(L), sum(L)//len(L), max(L))
